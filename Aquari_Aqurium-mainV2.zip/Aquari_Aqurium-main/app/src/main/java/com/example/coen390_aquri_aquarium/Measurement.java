package com.example.coen390_aquri_aquarium;



public class Measurement {
    public int year;
    public int month;
    public int day;
    public int hour;
    public int minute;
    public int seconds;
    public double temperature;
    public double pH;
    public double solids;

    public Measurement(int Year, int Month, int Day, int Hour, int Minute, int Seconds, double Temperature, double PH, double Solids){
        year=Year;
        month=Month;
        day=Day;
        hour=Hour;
        minute=Minute;
        seconds=Seconds;
        temperature=Temperature;
        pH=PH;
        solids=Solids;


    }
}
