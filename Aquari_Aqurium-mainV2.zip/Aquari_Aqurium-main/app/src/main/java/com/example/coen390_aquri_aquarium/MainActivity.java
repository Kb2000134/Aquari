package com.example.coen390_aquri_aquarium;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPointInterface;
import com.jjoe64.graphview.series.LineGraphSeries;

public class MainActivity extends AppCompatActivity {

    FirebaseDatabase database;
    DatabaseReference ref;
    //GraphView graphView;
    //LineGraphSeries series;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //graphView=(GraphView) findViewById(R.id.graphView);
       // series=new LineGraphSeries();
        //graphView.addSeries(series);
        database=FirebaseDatabase.getInstance();
        ref=database.getReference("measurement");

        /* ---------- Supposed to read for changes in the data and print when they happen
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Measurement measure=snapshot.getValue(Measurement.class);
                System.out.println(measure);}

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                System.out.println("The read Failed");
            }
        });*/


}

    public void sendData(Measurement measurement,DatabaseReference ref) {
        DatabaseReference pushRef=ref.push();
        pushRef.setValue(measurement);

    }

            /* ---------Example of how to send data to database
        DatabaseReference pushRef=ref.push();
        pushRef.setValue(new Measurement(2022,10,17,16,23,11,23,5.5,2));
        pushRef=ref.push();
        pushRef.setValue(new Measurement(2022,11,7,6,22,11,23.7,3.2,2.22));*/

}

